package factura;

public enum Tipo {
	Empresa, Particular;
}
